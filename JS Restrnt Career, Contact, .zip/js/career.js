window.onload=function() {
   // alert("Vasya");
 //  window.onload=Move();

 /* ==== Show / Hide Job Postings ======= */
/*
 $(function(){
    $("#jobs-button").click(function(){
        $("#jobs-section").toggle(1000);
        }) 
    });
*/
 
var jobsButton = document.getElementById("jobs-button");
var jobsSection = document.getElementById("jobs-section");

jobsButton.addEventListener("click", showJobs);
jobsSection.style.display = "none";

function showJobs() {
    if (jobsSection.style.display == "none") {
        jobsSection.style.display = "flex";
      } 
      else {
        jobsSection.style.display = "none";}
}

/* ==== Animated Div at the bottom =======
        animation code I found at https://www.freecodecamp.org/forum/t/setinterval-and-javascript-animation/172709;
        modified it a bit to work with 2 moving object;
*/
document.getElementById ("start-anim").addEventListener ("click", Move);
document.getElementById ("stop-anim").addEventListener ("click", Stop);

var id;

function Move() {
    var container = document.getElementById("animat-container");
    var element1 = document.getElementById("animate1");
    var element2 = document.getElementById("animate2");
    id = setInterval(frame, 20);
    var maxDistToTravel = container.offsetWidth - element1.offsetWidth; // container width-element width
    var position = 0;
    var end = maxDistToTravel;
    var direction = 1;
    
    function frame() { 
     if (position === end) {
       direction *= -1; // reverses current direction
       end = Math.abs(maxDistToTravel - end); 
     }

     position += direction;
     element1.style.left = position + "px";
     element2.style.right = position + "px";   
    }     
}
function Stop() {
     clearTimeout(id);
}

}




