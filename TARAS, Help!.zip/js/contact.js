window.onload=function() {
   // alert("Vasya");

  var success = document.getElementById("success");
  success.style.display = "none";

var s_form = document.forms.contact_form;
s_form.onsubmit = validateForm;

function validateForm () {
    var name = document.forms["contact_form"]["name"];              
    var email = document.forms["contact_form"]["email"];    
    var message = document.forms["contact_form"]["message"];  
    var noname = document.getElementById("noname");

	if (name.value === "" ||  !isNaN(name.value)) {
        noname.innerHTML = "Please enter Your Name"; 
        noname.style.border = "1px solid rgb(119, 216, 150)";
        name.focus();
        name.style.backgroundColor="#7ce698";
		return false;
    }

   	if (email.value === "" ) {
        noemail.innerHTML = "Please enter Your Email"; 
        noemail.style.border = "1px solid rgb(119, 216, 150)";
        email.focus();
        email.style.backgroundColor="#7ce698";
		return false;
    }
 
    if (message.value === "" ) {
        nomessage.innerHTML = "Please enter Your Message"; 
        nomessage.style.border = "1px solid rgb(119, 216, 150)";
        message.focus();
        message.style.backgroundColor="#7ce698";
		return false;
    }
else {
    success.style.display = "block";
    return true;
}
      
}
}